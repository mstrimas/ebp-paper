#ifndef _Rwrapper_hpp_
#define _Rwrapper_hpp_

#include "dglib.h"
#include <Rcpp.h>

#endif
