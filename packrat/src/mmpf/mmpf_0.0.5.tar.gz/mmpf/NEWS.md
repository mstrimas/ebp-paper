0.0.5

preserve column order from input data to makeDesign
