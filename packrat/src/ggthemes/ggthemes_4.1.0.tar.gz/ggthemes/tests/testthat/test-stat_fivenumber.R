context("stat-fivenumber")

test_that("stat_fivenumber works", {
  expect_is(stat_fivenumber(), "LayerInstance")
})
