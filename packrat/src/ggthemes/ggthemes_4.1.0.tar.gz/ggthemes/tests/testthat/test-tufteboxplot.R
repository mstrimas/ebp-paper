context("geom-tufteboxplot")

test_that("geom_tufteboxplot works", {
  expect_is(geom_tufteboxplot(), "LayerInstance")
})
