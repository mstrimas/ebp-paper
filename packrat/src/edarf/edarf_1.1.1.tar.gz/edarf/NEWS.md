edarf_0.1:

 - initial cran release
