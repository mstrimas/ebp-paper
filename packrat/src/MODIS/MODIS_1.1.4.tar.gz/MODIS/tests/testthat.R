library(testthat)
library(MODIS)

test_check("MODIS")
