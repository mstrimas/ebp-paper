library(testthat)
library(auk)

test_check("auk")
