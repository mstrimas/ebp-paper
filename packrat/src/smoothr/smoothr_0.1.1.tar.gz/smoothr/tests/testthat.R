library(testthat)
library(smoothr)

test_check("smoothr")
