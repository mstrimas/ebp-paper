library(testthat)
library(fasterize)

test_check("fasterize")
