categoricalval <-
function(x, category)
{
   ifelse(x==category, 1, 0)
}
