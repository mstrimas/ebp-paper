# maxnet 0.1.2

This is a new package, so no changes to document yet.