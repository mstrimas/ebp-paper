# maxnet
Maxent is a stand-alone Java application for modelling species geographic distributions.  This open source repository contains an R package, called "maxnet", which implements much of the functionality of the Java application.  We welcome contributions to maxnet.
The current release of maxnet is also available for download on the CRAN website.  

For information on the Maxent application, please see the Maxent home page at the American Museum of Natural History.  
